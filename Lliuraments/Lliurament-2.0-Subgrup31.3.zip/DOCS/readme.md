# PROP_FIB
Projecte de l'assignatura PROP de la FIB.

## Participants
- Mostazo González, Marc
- Tajahuerce Brulles, Arnau
- Costabella Moreno, Agustí
- Torredemer Pueyo , Francisco

## Emails
- marc.mostazo@estudiantat.upc.edu
- arnau.tajahuerce@estudiantat.upc.edu
- agusti.costabella@estudiantat.upc.edu
- francisco.torredemer@estudiantat.upc.edu