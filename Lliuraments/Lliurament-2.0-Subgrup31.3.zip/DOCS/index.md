# Directori DOCS

> Path absolut: /DOCS

## Descripció del directori

Aquest directori conté tota la documentació de la 2a entrega

## Elements del directori
- **Document 2a entrega.pdf** - Document de la 2a entrega

- **UML - Capa de Domini.svg** - Diagrama de classes de la capa de domini

- **UML - Capa de Persistència.svg** - Diagrama de classes de la capa de persistència

- **UML - Capa de Presentació.svg** - Diagrama de classes de la capa de presentació
