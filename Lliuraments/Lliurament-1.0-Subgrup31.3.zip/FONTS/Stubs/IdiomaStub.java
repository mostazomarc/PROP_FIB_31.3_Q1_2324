package Stubs;


import java.util.*;

public class IdiomaStub {

    private char[] lletres = "abcdefghijklmnopqrstuvwxyz".toCharArray();

    public char[] getLletres() {
        return lletres;
    }

    public IdiomaStub() {}
}