package Domini;

public class pos{
    public int x;
    public int y;

    public pos(int pos_x, int pos_y){
        this.x = pos_x;
        this.y = pos_y;
    }
}

//Francisco Torredemer
