## EXE/
Subdirectori amb els executables de l'entrega 3.

- **Main/**
    - Directori amb l'executable del programa principal de l'entrega 3.