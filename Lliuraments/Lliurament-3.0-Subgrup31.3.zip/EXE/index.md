## EXE/
Subdirectori amb els executables de l'entrega 3.

- **Main/**
    - Directori amb l'executable del programa principal de l'entrega 3.

- **JocsDeProva.pdf**
  - Aquest document conté els jocs de prova de la 3a entrega.

- **JocsDeProvaInputs_Outputs.pdf**
  - Aquest document conté els inputs i outputs dels jocs de prova de la 3a entrega.