/**
 * Package que conté les excepcions creades per l'aplicació.
 */
package Excepcions;