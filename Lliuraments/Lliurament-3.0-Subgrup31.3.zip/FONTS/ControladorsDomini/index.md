## ControladorsDomini/
Aquest directori conté el codi dels controladors de la capa de domini.

- **CtrlDomini.java**
    - Codi del controlador de la capa de domini encarregat de comunicar-se amb les capes de presentació i dades.

- **package-info.java**
    - Conté la informació per al JavaDoc del package.