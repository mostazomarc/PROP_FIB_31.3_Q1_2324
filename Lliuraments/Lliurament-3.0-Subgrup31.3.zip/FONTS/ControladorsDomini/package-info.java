/**
 * Package que conte tots els controladors de domini.
 */
package ControladorsDomini;