/**
 * Package que conte les classes del domini
 */
package Domini;