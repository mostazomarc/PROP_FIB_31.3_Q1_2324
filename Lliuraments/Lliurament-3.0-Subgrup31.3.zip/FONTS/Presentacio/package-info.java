/**
 * Package que conté les classes de la capa de presentació del programa
 */
package Presentacio;