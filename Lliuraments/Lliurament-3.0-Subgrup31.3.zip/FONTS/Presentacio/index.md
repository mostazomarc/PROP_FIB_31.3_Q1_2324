## Presentacio/
Aquest subdirectori conté el codi de les classes de la capa de presentació.

- **/Views/**
    - Conté el codi de les vistes del programa.

- **ControladorPresentacio.java**
    - Codi del controlador de presentació encarregat de la comunicació entre capes.

- **Main.java**
    - Main del programa.

- **Main.mf**
    - Manifest del programa.

- **package-info.java**
    - Conté la informació per al JavaDoc del package.