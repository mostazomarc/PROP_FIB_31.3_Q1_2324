## Dades/
Aquest subdirectori conté el codi dels controladors de persistència del sistema i del controlador per llegir arxius txt.

- **CtrlFile.java**
    - Codi del controlador per llegir arxius txt.

- **CtrlPersAlfabets.java**
    - Codi del controlador de persistència dels Alfabets.

- **CtrlPersFreq.java**
    - Codi del controlador de persistència de les llistes de freqüència.

- **CtrlPersIdiomes.java**
    - Codi del controlador de persistència dels Idiomes.

- **CtrlPersPerfil.java**
    - Codi del controlador de persistència dels Perfils.

- **CtrlPersTeclats.java**
    - Codi del controlador de persistència dels Teclats.

- **package-info.java**
    - Conté la informació per al JavaDoc del package.