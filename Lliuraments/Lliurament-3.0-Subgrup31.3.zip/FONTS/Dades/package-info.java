/**
 * Package que conté les classes que gestionen les dades de l'aplicació.
 */
package Dades;