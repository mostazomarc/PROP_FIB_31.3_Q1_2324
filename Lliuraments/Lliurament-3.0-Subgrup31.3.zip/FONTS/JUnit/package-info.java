/**
 * Package que conte les classes de JUnit per fer els tests
 */
package JUnit;