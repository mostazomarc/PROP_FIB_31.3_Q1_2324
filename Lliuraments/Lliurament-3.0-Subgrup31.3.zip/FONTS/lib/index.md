## lib/
Subdirectori amb les llibreries externes que necessita el projecte.

- **hamcrest-core-1.3.jar**
    - Jar necessari per JUNIT.

- **json-simple-1.1.jar**
    - Jar necessari per les operacions amb JSON.

- **junit-4.13.2.jar**
    - Jar necessari per JUNIT.