## DOCS/
Aquest directori conté tota la documentació de la 3a entrega.

- **Javadoc/**
  - Aquest directori conté la documentació de la 3a entrega en format javadoc.

- **JocsDeProva.pdf**
  - Aquest document conté els jocs de prova de la 3a entrega.

- **JocsDeProvaInputs_Outputs.pdf**
  - Aquest document conté els inputs i outputs dels jocs de prova de la 3a entrega.

- **Manual d'Usuari.pdf**
  - Aquest document conté el manual d'usuari de la 3a entrega.

- **RelacióClasses-Membre.pdf**
  - Aquest document conté la relació de classes programades per membres de la 3a entrega.