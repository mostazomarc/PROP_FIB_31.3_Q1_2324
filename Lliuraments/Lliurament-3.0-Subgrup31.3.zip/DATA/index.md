## DATA/
Directori amb la info guardada del projecte i amb els fitxers proporcionats per a ser utilitzats com a input del programa.

- **Alfabets/**
    - Directori amb fitxers d'alfabets per a utilitzar com a input del programa.

- **LlistesFrequencies/**
    - Directori amb fitxers de llistes de frequencies per a utilitzar com a input del programa.

- **Saves/**
    - Directori on es guarden els `.json` amb les dades persistents del sistema.

- **TextsFrequencies/**
    - Directori amb fitxers de textos per a utilitzar com a input del programa.